from flask import Flask, render_template, request
import random

app = Flask(__name__)

def generate_otp(length=6):
    return "".join(str(random.randint(0, 9)) for _ in range(length))

@app.route("/", methods=["GET", "POST"])
def home():
    otp = None
    if request.method == "POST":
        otp = generate_otp()
    return render_template("index.html", otp=otp)

if __name__ == "__main__":
    app.run(debug=True)
